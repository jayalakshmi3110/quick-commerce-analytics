-- Create the analytics view--
-- A view joins the 3 tables into one clean table. Power BI will import only this view.--

CREATE VIEW vw_sales AS
SELECT o.order_id,
 o.order_date,
 c.customer_id,
 c.city,
 p.product_name,
 p.category,
 o.quantity,
 o.discount_pct,
 o.delivery_minutes,
 o.rating,
 ROUND(p.price * o.quantity * (1 - o.discount_pct/100), 2) AS revenue,
 CASE WHEN o.delivery_minutes <= 15 THEN '1. Under 15 min'
 WHEN o.delivery_minutes <= 25 THEN '2. 16-25 min'
 ELSE '3. Over 25 min' END AS delivery_bucket
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN products p ON o.product_id = p.product_id;

SELECT COUNT(*) AS total_rows, ROUND(SUM(revenue)) AS total_revenue FROM vw_sales;
