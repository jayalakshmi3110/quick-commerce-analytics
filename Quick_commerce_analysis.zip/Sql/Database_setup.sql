DROP DATABASE IF EXISTS quickcommerce;
CREATE DATABASE quickcommerce;
USE quickcommerce;
-- ---------- 1. TABLES ----------
CREATE TABLE customers (
 customer_id INT PRIMARY KEY,
 city VARCHAR(30),
 signup_date DATE
);
CREATE TABLE products (
 product_id INT PRIMARY KEY,
 product_name VARCHAR(50),
 category VARCHAR(30),
 price DECIMAL(8,2)
);
CREATE TABLE orders (
 order_id INT PRIMARY KEY,
 customer_id INT,
 product_id INT,
 order_date DATE,
 quantity INT,
 discount_pct DECIMAL(4,1),
 delivery_minutes INT,
 rating INT,
 FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
 FOREIGN KEY (product_id) REFERENCES products(product_id)
);

SET SESSION cte_max_recursion_depth = 100000;
INSERT INTO products VALUES
(1,'Toned Milk 1L','Dairy',56),(2,'Fresh Curd 400g','Dairy',40),
(3,'Paneer 200g','Dairy',95),(4,'Eggs (12)','Dairy',84),
(5,'Bananas 1kg','Fruits & Veg',60),(6,'Tomatoes 1kg','Fruits & Veg',45),
(7,'Onions 1kg','Fruits & Veg',38),(8,'Apples 1kg','Fruits & Veg',180),
(9,'Potato Chips','Snacks',20),(10,'Instant Noodles','Snacks',14),
(11,'Chocolate Bar','Snacks',50),(12,'Cola 750ml','Beverages',40),
(13,'Cold Coffee','Beverages',75),(14,'Energy Drink','Beverages',110),
(15,'Shampoo 340ml','Personal Care',270),(16,'Face Wash','Personal Care',190),
(17,'Toothpaste','Personal Care',95),(18,'Detergent 1kg','Household',210),
(19,'Dish Wash Gel','Household',130),(20,'Basmati Rice 5kg','Staples',620),
(21,'Wheat Atta 5kg','Staples',280),(22,'Sunflower Oil 1L','Staples',150);
INSERT INTO customers (customer_id, city, signup_date)
WITH RECURSIVE seq AS (
 SELECT 1 AS n UNION ALL SELECT n + 1 FROM seq WHERE n < 2000
)
SELECT n,
 ELT(1 + FLOOR(RAND()*6),'Chennai','Bengaluru','Mumbai','Delhi','Hyderabad','Pune'),
 DATE_ADD('2024-01-01', INTERVAL FLOOR(RAND()*365) DAY)
FROM seq;
INSERT INTO orders (order_id, customer_id, product_id, order_date, quantity,
 discount_pct, delivery_minutes, rating)
WITH RECURSIVE seq AS (
 SELECT 1 AS n UNION ALL SELECT n + 1 FROM seq WHERE n < 30000
)
SELECT n,
 1 + FLOOR(RAND()*2000),
 1 + FLOOR(RAND()*22),
 DATE_ADD('2025-01-01', INTERVAL FLOOR(RAND()*638) DAY),
 1 + FLOOR(RAND()*4),
 ELT(1 + FLOOR(RAND()*4), 0, 5, 10, 20),
 8 + FLOOR(RAND()*33),
 3
FROM seq;
-- Make ratings realistic: slower delivery = lower rating
UPDATE orders
SET rating = CASE
 WHEN delivery_minutes <= 15 THEN 4 + FLOOR(RAND()*2)
 WHEN delivery_minutes <= 25 THEN 3 + FLOOR(RAND()*3)
 ELSE 1 + FLOOR(RAND()*3)
 END
WHERE order_id > 0;

SELECT COUNT(*) FROM orders;

