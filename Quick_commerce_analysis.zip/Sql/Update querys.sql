use quickcommerce;
SELECT * FROM vw_sales;

SELECT COUNT(*) AS total_rows, ROUND(SUM(revenue)) AS total_revenue FROM vw_sales;
USE quickcommerce;

-- Make Mumbai and Delhi slower (traffic story)
UPDATE orders o
JOIN customers c ON o.customer_id = c.customer_id
SET o.delivery_minutes = o.delivery_minutes + 8
WHERE c.city IN ('Mumbai','Delhi') AND o.order_id > 0;

-- Make Bengaluru the biggest market
UPDATE customers
SET city = 'Bengaluru'
WHERE city = 'Pune' AND customer_id % 2 = 0 AND customer_id > 0;

-- Re-create ratings so they follow the new delivery times
UPDATE orders
SET rating = CASE
      WHEN delivery_minutes <= 15 THEN 4 + FLOOR(RAND()*2)
      WHEN delivery_minutes <= 25 THEN 3 + FLOOR(RAND()*3)
      ELSE 1 + FLOOR(RAND()*3)
    END
WHERE order_id > 0;

USE quickcommerce;

-- 1. Uneven city sizes (Bengaluru and Mumbai biggest, Pune smallest)
UPDATE customers
SET city = ELT(1 + FLOOR(RAND()*20),
  'Bengaluru','Bengaluru','Bengaluru','Bengaluru','Bengaluru',
  'Mumbai','Mumbai','Mumbai','Mumbai','Mumbai',
  'Delhi','Delhi','Delhi','Delhi',
  'Chennai','Chennai','Chennai',
  'Hyderabad','Hyderabad',
  'Pune')
WHERE customer_id > 0;

-- 2. Different delivery speed per city
UPDATE orders o
JOIN customers c ON o.customer_id = c.customer_id
SET o.delivery_minutes = 8 + FLOOR(RAND()*25) +
    CASE c.city
      WHEN 'Mumbai'    THEN 8
      WHEN 'Delhi'     THEN 6
      WHEN 'Bengaluru' THEN 4
      WHEN 'Chennai'   THEN 1
      WHEN 'Hyderabad' THEN 0
      ELSE -2
    END
WHERE o.order_id > 0;

-- 3. Ratings follow delivery time again
UPDATE orders
SET rating = CASE
      WHEN delivery_minutes <= 15 THEN 4 + FLOOR(RAND()*2)
      WHEN delivery_minutes <= 25 THEN 3 + FLOOR(RAND()*3)
      ELSE 1 + FLOOR(RAND()*3)
    END
WHERE order_id > 0;

-- Check the result
SELECT city, COUNT(*) AS orders, ROUND(SUM(revenue)) AS revenue,
       ROUND(AVG(delivery_minutes),1) AS avg_delivery, ROUND(AVG(rating),2) AS avg_rating
FROM vw_sales GROUP BY city ORDER BY orders DESC;

SELECT * FROM vw_sales;
